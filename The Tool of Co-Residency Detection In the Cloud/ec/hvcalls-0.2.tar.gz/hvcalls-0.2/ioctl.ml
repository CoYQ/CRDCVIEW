(* ioctl syscall for OCaml.
 * $Id: ioctl.ml,v 1.1 2007/06/13 10:08:51 rjones Exp $
 *)

external ioctl : Unix.file_descr -> int32 -> string -> int32 = "caml_ioctl"

(* See <asm-generic/ioctl.h> *)

module Linux = struct
  type struct ioc = {
    dir : int:2;
    size : int:14;
    typ : int:8;
    nr : int:8
  }

  let ioc_none  = 0
  let ioc_write = 1
  let ioc_read  = 2
end
