(* Structures with bitfields.
 * $Id: pa_bitfields.ml,v 1.5 2007/06/14 16:51:07 rjones Exp $
 *)

open Printf
open Camlp4.PreCast

let option_map f = function
  | None -> None
  | Some x -> Some (f x)

(* Check that a list of strings contains only unique names, and if
 * not, throw an error.
 *)
let check_unique _loc names =
  let tbl = Hashtbl.create 50 in
  List.iter
    (fun name -> 
       if Hashtbl.mem tbl name then
         Loc.raise _loc
           (Failure (name ^ ": this name is not unique"))
       else Hashtbl.add tbl name ())
    names

(* Check all the same, else call error function. *)
let rec check_all_same error_fn =
  function
  | [] | [_] -> ()
  | x :: ((y :: _) as xs) ->
      if compare x y = 0 then check_all_same error_fn xs
      else error_fn ()

(* Go right into each field and check that the types and bit sizes
 * make sense.
 *)
let check_fields xs =
  List.iter (
    fun (_, _, fields, _) ->
      List.iter (
	fun (_loc, name, len, typ, bits, options) ->
	  (match len with
	   | None -> ()
	   | Some len ->
	       if len <= 0 then
		 Loc.raise _loc
		   (Failure (name ^ "[]: array length must be > 0")));

	  (match bits with
	   | None -> ()
	   | Some bits ->
	       if bits <= 0 then
		 Loc.raise _loc
		   (Failure (name ^ ": bits must be > 0")));

	  (match typ with
	   | "char" ->
	       if bits > Some 8 then
		 Loc.raise _loc
		   (Failure (name ^ ": char type must have bits <= 8"))

	   | "int" ->
	       (match bits with
		| None ->
		    Loc.raise _loc
		      (Failure (name ^ ": int type must specify bit length"))
		| Some bits ->
		    if bits > 31 then
		      Loc.raise _loc
			(Failure (name ^ ": int type must have bits <= 31 (use int32/int64/nativeint instead)")))

	   | "int32" ->
	       if bits > Some 32 then
		 Loc.raise _loc
		   (Failure (name ^ ": int32 type must have bits <= 32"))

	   | "int64" ->
	       if bits > Some 64 then
		 Loc.raise _loc
		   (Failure (name ^ ": int64 type must have bits <= 64"))

	   | "nativeint" ->
	       if bits > Some (Nativeint.size) then
		 Loc.raise _loc
		   (Failure (name ^ ": nativeint type must have bits <= " ^ string_of_int Nativeint.size ^ " on this architecture"))

	   | _ ->
	       Loc.raise _loc
		 (Failure (typ ^ ": unknown type")))
      ) fields
  ) xs

(* String.split and String.nsplit from extlib *)
exception Invalid_string

let string_find str sub =
  let sublen = String.length sub in
  if sublen = 0 then
    0
  else
    let found = ref 0 in
    let len = String.length str in
    try
      for i = 0 to len - sublen do
        let j = ref 0 in
        while String.unsafe_get str (i + !j) = String.unsafe_get sub !j do
          incr j;
          if !j = sublen then begin found := i; raise Exit; end;
        done;
      done;
      raise Invalid_string
    with
      Exit -> !found

let string_split str sep =
  let p = string_find str sep in
  let len = String.length sep in
  let slen = String.length str in
  String.sub str 0 p, String.sub str (p + len) (slen - p - len)

let string_nsplit str sep =
  if str = "" then []
  else (
    let rec nsplit str sep =
      try
        let s1 , s2 = string_split str sep in
        s1 :: nsplit s2 sep
      with
        Invalid_string -> [str]
    in
    nsplit str sep
  )

type option_t = {
  endianness : Bitfields_helper.endianness option;
}

(* Parse the options field (a string option into an option_t). *)
let parse_options ?(default_options = { endianness = None }) _loc =
  function
  | None | Some "" ->
      default_options
  | Some options ->
      let options = string_nsplit options "," in
      let t = default_options in
      let options = List.fold_left (
	fun t ->
	  function
	  | "bigendian" | "BigEndian" | "BE" ->
	      { (*t with*) endianness = Some Bitfields_helper.Big_Endian }
	  | "littleendian" | "LittleEndian" | "LE" ->
	      { (*t with*) endianness = Some Bitfields_helper.Little_Endian }
	  | str ->
	      Loc.raise _loc
		(Failure (str ^ ": unrecognised option"))
      ) t options in
      options

(* If the bit length isn't specified, set a default. *)
let set_default_bit_lengths _loc fields =
  List.map (
    function
    | (_loc, name, len, typ, Some bits, options) ->
	_loc, name, len, typ, bits, options
    | (_loc, name, len, ("char" as typ), None, options) ->
	_loc, name, len, typ, 8, options
    | (_loc, name, len, "int", None, options) ->
	assert false (* can't happen - see check_fields *)
    | (_loc, name, len, ("int32" as typ), None, options) ->
	_loc, name, len, typ, 32, options
    | (_loc, name, len, ("int64" as typ), None, options) ->
	_loc, name, len, typ, 64, options
    | (_loc, name, len, ("nativeint" as typ), None, options) ->
	_loc, name, len, typ, Nativeint.size, options
    | _ ->
	assert false (* shouldn't happen if check_fields is correct *)
  ) fields

let rec range a b =
  if a > b then []
  else a :: range (a+1) b

let sum = List.fold_left (+) 0

(* Get the first elements of a list and the final element.  Sort of like
 * hd::tl but in reverse and much less efficient.  Assumes xs <> [].
 *)
let first_last xs =
  let xs = List.rev xs in
  let last, first = List.hd xs, List.tl xs in
  let first = List.rev first in
  first, last

(* Flatten out array fields.
 * A field like array[5] : int is just shorthand for
 * array0 : int; array1 : int; ...
 *)
let flatten_array_fields _loc fields =
  List.concat (
    List.map (
      function
      | (_loc, name, (None | Some 1), typ, bits, options) ->
	  [ _loc, name, typ, bits, options ]
      | (_loc, name, Some n, typ, bits, options) ->
	  List.map (
	    fun i ->
	      (_loc, name ^ string_of_int i, typ, bits, options)
	  ) (range 0 (n-1))
    ) fields
  )

(* For each 'type struct', generate the actual type definition. *)
let make_typedef (_loc, name, fields, _) =
  let fields =
    List.map (
      fun (_loc, name, typ, _, _) ->
	<:ctyp< $lid:name$ : $lid:typ$ >>
    ) fields in

  <:str_item< type $lid:name$ = { $list:fields$ } >>

(* Get the bit offsets of fields which we will be packing into
 * a 32- or 64-bit int.
 *)
let get_offsets fields =
  let fields, _ =
    List.fold_right (
      fun (_loc, name, typ, bits, options) (fields, offset) ->
	((_loc, name, typ, bits, options, offset)::fields, bits+offset)
    ) fields ([], 0) in
  fields

(* Get the function which converts from typ to intN (if N = 0 then int). *)
let intN_of_typ _loc typ n =
  match (typ, n) with
  | "char", 0
  | "char", 32
  | "char", 64 ->      failwith "intN_of_typ: not implemented yet for chars"
  | "int", 32 ->       Some <:expr< Int32.of_int >>
  | "int", 64 ->       Some <:expr< Int64.of_int >>
  | "int32", 0 ->      Some <:expr< Int32.to_int >>
  | "int32", 64 ->     Some <:expr< Int64.of_int32 >>
  | "int64", 0 ->      Some <:expr< Int64.to_int >>
  | "int64", 32 ->     Some <:expr< Int64.to_int32 >>
  | "nativeint", 0 ->  Some <:expr< Nativeint.to_int >>
  | "nativeint", 32 -> Some <:expr< Nativeint.to_int32 >>
  | "nativeint", 64 -> Some <:expr< Int64.of_nativeint >>

  | "int", 0
  | "int32", 32
  | "int64", 64 ->     None

  | _ -> assert false

(* Get the function which converts from intN to typ (if N = 0 then int). *)
let typ_of_intN _loc n typ =
  match (n, typ) with
  | 0, "char"
  | 32, "char"
  | 64, "char" ->      failwith "typ_of_intN: not implemented yet for chars"
  | 32, "int" ->       Some <:expr< Int32.to_int >>
  | 64, "int" ->       Some <:expr< Int64.to_int >>
  | 0, "int32" ->      Some <:expr< Int32.of_int >>
  | 64, "int32" ->     Some <:expr< Int64.to_int32 >>
  | 0, "int64" ->      Some <:expr< Int64.of_int >>
  | 32, "int64" ->     Some <:expr< Int64.of_int32 >>
  | 0, "nativeint" ->  Some <:expr< Nativeint.of_int >>
  | 32, "nativeint" -> Some <:expr< Nativeint.of_int32 >>
  | 64, "nativeint" -> Some <:expr< Int64.to_nativeint >>

  | 0, "int"
  | 32, "int32"
  | 64, "int64" ->     None

  | _ -> assert false

(* bitmask_of_bits creates a bitmask of length bits.
 * For example, bitmask_of_bits 16 --> 0xffff
 *)
let rec bitmask_of_bits =
  function
  | 0 -> 0_L
  | i when i > 0 ->
      Int64.logor (Int64.shift_left (bitmask_of_bits (i-1)) 1) 1_L
  | _ -> failwith "bitmask_of_bits called with negative number"

(* Write int_of_foo, int32_of_foo or int64_of_foo function.
 * Note that there are no endianness concerns for internal integers.
 *)
let make_intN_of_foo _loc n name fields =
  let function_name, shift_left, logor =
    match n with
    | 0 ->
	"int_of_" ^ name, <:expr< $lid:"lsl"$ >>, <:expr< $lid:"lor"$ >>
    | 32 ->
	"int32_of_" ^ name,
	<:expr< Int32.shift_left >>,
	<:expr< Int32.logor >>
    | 64 ->
	"int64_of_" ^ name,
	<:expr< Int64.shift_left >>,
	<:expr< Int64.logor >>
    | _ -> assert false in
  let fields, last_field = first_last fields in
  let fields = List.map (
    fun (_, name, typ, _, _, offset) ->
      let converter = intN_of_typ _loc typ n in
      match converter with
      | Some converter ->
	  <:expr< $shift_left$ ($converter$ p.$lid:name$) $`int:offset$ >>
      | None ->
	  <:expr< $shift_left$ p.$lid:name$ $`int:offset$ >>
  ) fields in
  let last_field =
    let (_, name, typ, _, _, offset) = last_field in
    assert (offset = 0);
    let converter = intN_of_typ _loc typ n in
    match converter with
    | Some converter -> <:expr< $converter$ p.$lid:name$ >>
    | None -> <:expr< p.$lid:name$ >> in
  let body = List.fold_right (
    fun body field ->
      <:expr< $logor$ $field$ $body$ >>
  ) fields last_field in
  <:str_item<
    value $lid:function_name$ p = $body$
  >>

(* Write foo_of_int, foo_of_int32 or foo_of_int64 function.
 * Note that there are no endianness concerns for internal integers.
 *)
let make_foo_of_intN _loc n name fields =
  let function_name, shift_right, logand, expr_of_int =
    match n with
    | 0 ->
	name ^ "_of_int",
	<:expr< $lid:"lsr"$ >>,
	<:expr< $lid:"land"$ >>,
	fun i -> let i = Int64.to_int i in <:expr< $`int:i$ >>
    | 32 ->
	name ^ "_of_int32",
	<:expr< Int32.shift_right_logical >>,
	<:expr< Int32.logand >>,
	fun i -> let i = Int64.to_int32 i in <:expr< $`int32:i$ >>
    | 64 ->
	name ^ "_of_int64",
	<:expr< Int64.shift_right_logical >>,
	<:expr< Int64.logand >>,
	fun i -> <:expr< $`int64:i$ >>
    | _ -> assert false in
  let fields, last_field = first_last fields in
  let fields = List.map (
    fun (_, name, typ, bits, _, offset) ->
      let converter = typ_of_intN _loc n typ in
      let bitmask = bitmask_of_bits bits in
      let bitmask = expr_of_int bitmask in
      match converter with
      | Some converter ->
	  <:rec_binding< $lid:name$ = $converter$ ($logand$ ($shift_right$ i $`int:offset$) $bitmask$) >>
      | None ->
	  <:rec_binding< $lid:name$ = $logand$ ($shift_right$ i $`int:offset$) $bitmask$ >>
  ) fields in
  let last_field =
    let (_, name, typ, bits, _, offset) = last_field in
    assert (offset = 0);
    let converter = typ_of_intN _loc n typ in
    let bitmask = bitmask_of_bits bits in
    let bitmask = expr_of_int bitmask in
    match converter with
    | Some converter -> <:rec_binding< $lid:name$ = $converter$ ($logand$ i $bitmask$) >>
    | None -> <:rec_binding< $lid:name$ = $logand$ i $bitmask$ >> in
  let fields = last_field :: fields in
  <:str_item<
    value $lid:function_name$ i = { $list:fields$ }
  >>

let zero_of_typ _loc = function
  | "char" -> <:expr< Char.chr 0 >>
  | "int" -> <:expr< $`int:0$>>
  | "int32" -> <:expr< $`int32:0_l$ >>
  | "int64" -> <:expr< $`int64:0_L$ >>
  | "nativeint" -> <:expr< $`nativeint:0n$ >>
  | typ -> failwith ("zero_of_typ: " ^ typ ^ ": not implemented for this type")

(* Check that the endianness options for all fields in a related group
 * are the same.
 *)
let check_group_endianness _loc name fields =
  assert (fields <> []);
  let endians = List.map (
    fun (_, _, _, _, options) ->
      let endianness = options.endianness in
      endianness
  ) fields in
  check_all_same
    (fun () ->
       Loc.raise _loc
	 (Failure (name ^ ": enddianness within bitfields must match")))
    endians

(* Group fields into together that fit into a 32 or 64 bit word.  It
 * is an error for bitfields to cross 32 bit word boundaries.
 *
 * XXX This cannot handle bitfields wider than 32 bits.  There should
 * be a per-struct option to allow this.
 *)
let get_groups _loc name fields =
  let groups = ref [] in
  let next_group = ref [] in
  let bits_in_next_group = ref 0 in
  List.iter (
    fun ((_loc, name, _, bits, _) as field) ->
      try
	(* Aligned? *)
	if !bits_in_next_group = 0 then (
	  (* Aligned int32? *)
	  if bits = 32 then (
	    groups := [field] :: !groups;
	    raise Exit
	  (* Aligned int64? *)
	  ) else if bits = 64 then (
	    groups := [field] :: !groups;
	    raise Exit
	  )
	);

	(* We're in a bitfield, so start packing until we hit 32 bits. *)
	if !bits_in_next_group + bits < 32 then (
	  next_group := field :: !next_group;
	  bits_in_next_group := !bits_in_next_group + bits
	) else if !bits_in_next_group + bits = 32 then (
	  groups := (List.rev (field :: !next_group)) :: !groups;
	  next_group := [];
	  bits_in_next_group := 0
	) else (
	  Loc.raise _loc
	    (Failure (name ^ ": bitfield crosses 32 bit word boundary"))
	)
      with
	Exit -> ()
  ) fields;

  (* XXX It's not clear what the semantics are if there are remaining
   * fields < 32 bits wide, so we disallow it here.  A consequence of
   * this is that all structures must be a multiple of 32 bits long.
   *)
  if !bits_in_next_group <> 0 then
    Loc.raise _loc
      (Failure (name ^ ": structure must be a multiple of 32 bits long"));

  (* Get the groups in the right order. *)
  let groups = List.rev !groups in

  (* Check that the endianness options for all fields in a related group
   * are the same.
   *)
  List.iter (check_group_endianness _loc name) groups;

  groups

(* Get the name of the Bitfields_helper.write_x_unsafe function. *)
let helper_write_unsafe typ bits endianness =
  sprintf "write_%s_%d_%s_unsafe" typ bits (
    match endianness with
    | Bitfields_helper.Big_Endian -> "be"
    | Bitfields_helper.Little_Endian -> "le"
  )

(* The bits_of_foo function packs the foo structure into a string.
 *
 * Endianness _is_ a concern here:
 *
 *   For basic int32 and int64 fields we write them out with the
 *   endianness specified by the options (default to native endianness).
 *
 *   For bitfields, we first pack them into 32-bit words, and then
 *   write out with the endianness specified for the bitfields.  All
 *   bitfields must specify the same endianness, else it is an error.
 *
 * Bitfields must not cross 32-bit word boundaries.
 *
 * bits_of_foo allocates the string.
 *
 * bits_of_foo'string packs into an already allocated string.
 *
 * bits_of_foo'unsafe is the underlying function which does no
 *   checking on the length of the string.
 *)
let make_bits_of_foo_unsafe _loc name groups =
  let function_name = "bits_of_" ^ name ^ "'unsafe" in

  (* XXX Assume List.map always runs forwards. *)
  let index = ref 0 in

  let stmts = List.map (
    fun fields ->
      let total_bits =
	sum (List.map (fun (_, _, _, bits, _) -> bits) fields) in
      (* If you hit the following assertion then get_groups is wrong: *)
      assert (total_bits = 32 || total_bits = 64);

      let stmts =
	match fields with
	| [] ->
	    assert false (* If you hit this then get_groups is wrong. *)

	| [_loc, name, typ, bits, {endianness = endianness}] ->
	    let endianness =
	      match endianness with
	      | None -> Bitfields_helper.platform_endianness ()
	      | Some endianness -> endianness in

	    let helper_fn = helper_write_unsafe typ bits endianness in
	    [ <:expr<
	      Bitfields_helper.$lid:helper_fn$ p.$lid:name$ str $`int:!index$
	      >> ]

	| fields ->			(* Bitfield. *)
	    assert (total_bits = 32);	(* They are always 32 bits long. *)

	    (* XXX bitfields *)






	    [ <:expr< () >> ] in

      index := !index + total_bits / 8;
      stmts
  ) groups in
  let stmts = List.flatten stmts in

  <:str_item<
    value $lid:function_name$ p str = do { $list:stmts$ }
  >>

let make_bits_of_foo_string _loc name _ =
  let function_name = "bits_of_" ^ name ^ "'string" in
  let sizeof_name = "sizeof_" ^ name in
  let unsafe_name = "bits_of_" ^ name ^ "'unsafe" in

  <:str_item<
    value $lid:function_name$ p str =
      do {
        assert (String.length str >= $lid:sizeof_name$);
        $lid:unsafe_name$ p str
      }
  >>

let make_bits_of_foo _loc name _ =
  let function_name = "bits_of_" ^ name in
  let sizeof_name = "sizeof_" ^ name in
  let string_name = "bits_of_" ^ name ^ "'string" in

  <:str_item<
    value $lid:function_name$ p =
      let str = String.create $lid:sizeof_name$ in
      do { $lid:string_name$ p str; str }
  >>

(* Get the name of the Bitfields_helper.read_x_unsafe function. *)
let helper_read_unsafe typ bits endianness =
  sprintf "read_%s_%d_%s_unsafe" typ bits (
    match endianness with
    | Bitfields_helper.Big_Endian -> "be"
    | Bitfields_helper.Little_Endian -> "le"
  )

(* Make the foo_of_bits functions.
 *
 * foo_of_bits reads a single foo structure from the string.
 *
 * foo_of_bits'unsafe is the same but does not check string length.
 *
 * foo_of_bits'offset reads a single foo from an offset in the string.
 *
 * foo_of_bits'offset'unsafe is the unsafe version.
 *)
let make_foo_of_bits_unsafe ?(offset=false) _loc name groups =
  let function_name =
    name ^ "_of_bits" ^
      (if not offset then "" else "'offset") ^
      "'unsafe" in

  (* XXX Assume List.map always runs forwards. *)
  let index = ref 0 in

  let rec_bindings = List.map (
    fun fields ->
      let total_bits =
	sum (List.map (fun (_, _, _, bits, _) -> bits) fields) in
      (* If you hit the following assertion then get_groups is wrong: *)
      assert (total_bits = 32 || total_bits = 64);

      let rec_bindings =
	match fields with
	| [] ->
	    assert false (* If you hit this then get_groups is wrong. *)

	| [_loc, name, typ, bits, {endianness = endianness}] ->
	    let endianness =
	      match endianness with
	      | None -> Bitfields_helper.platform_endianness ()
	      | Some endianness -> endianness in

	    let helper_fn = helper_read_unsafe typ bits endianness in

	    if not offset then
	      [ <:rec_binding<
		$lid:name$ = Bitfields_helper.$lid:helper_fn$ str $`int:!index$
		>>]
	    else
	      [ <:rec_binding<
		$lid:name$ = Bitfields_helper.$lid:helper_fn$
		  str (offset + $`int:!index$)
	        >> ]

	| fields ->
	    assert (total_bits = 32);	(* They are always 32 bits long. *)

	    (* XXX bitfields *)






	    List.map (
	      fun (_loc, name, typ, _, _) ->
		let zero = zero_of_typ _loc typ in
		<:rec_binding<
		  $lid:name$ = $zero$
		>>
	    ) fields in

      index := !index + total_bits / 8;
      rec_bindings
  ) groups in
  let rec_bindings = List.flatten rec_bindings in

  if not offset then
    <:str_item<
      value $lid:function_name$ str = { $list:rec_bindings$ }
      >>
  else
    <:str_item<
      value $lid:function_name$ str offset = { $list:rec_bindings$ }
      >>

let make_foo_of_bits ?(offset=false) _loc name groups =
  let function_name =
    name ^ "_of_bits" ^
      (if not offset then "" else "'offset") in
  let sizeof_name = "sizeof_" ^ name in
  let unsafe_name =
    name ^ "_of_bits" ^
      (if not offset then "" else "'offset") ^
      "'unsafe" in

  if not offset then
    <:str_item<
      value $lid:function_name$ str =
        do {
	  assert (String.length str >= $lid:sizeof_name$);
	  $lid:unsafe_name$ str
	}
    >>
 else
    <:str_item<
      value $lid:function_name$ str offset =
        do {
	  assert (String.length str >= offset + $lid:sizeof_name$);
	  $lid:unsafe_name$ str offset
	}
    >>

(* Make an expression which is the foo structure with all fields set
 * to zero.  This is useful for structures which have a lot of default /
 * don't care / padding fields.
 *)
let make_zero_foo _loc name fields =
  let expr_name = "zero_" ^ name in
  let fields = List.map (
    fun (_, name, typ, _, _) ->
      let zero = zero_of_typ _loc typ in
      <:rec_binding< $lid:name$ = $zero$ >>
  ) fields in
  <:str_item<
    value $lid:expr_name$ = { $list:fields$ }
  >>

(* For each 'type struct', generate the *_of_* functions. *)
let make_functions (_loc, name, fields, _) =
  (* Work out how large the whole type is, in bits. *)
  let total_bits = sum (List.map (fun (_, _, _, bits, _) -> bits) fields) in

  (* Fail if the field isn't a multiple of 8 bits. *)
  if 0 <> total_bits mod 8 then
    Loc.raise _loc
      (Failure (name ^ ": structure must be a round number of bytes in size (it is " ^ string_of_int total_bits ^ " bits)"));

  let functions = [] in

  (* Write int64_of_foo and foo_of_int64 functions. *)
  let functions =
    if total_bits <= 64 then (
      let fields = get_offsets fields in
      let int64_of_foo = make_intN_of_foo _loc 64 name fields in
      let foo_of_int64 = make_foo_of_intN _loc 64 name fields in
      int64_of_foo :: foo_of_int64 :: functions
    ) else functions in

  (* Write int32_of_foo and foo_of_int32 functions.
   * XXX Optimisation:
   *   On 64-bit arch we should just wrap around int_of_foo and foo_of_int.
   *)
  let functions =
    if total_bits <= 32 then (
      let fields = get_offsets fields in
      let int32_of_foo = make_intN_of_foo _loc 32 name fields in
      let foo_of_int32 = make_foo_of_intN _loc 32 name fields in
      int32_of_foo :: foo_of_int32 :: functions
    ) else functions in

  (* Write int_of_foo and foo_of_int functions. *)
  let functions =
    if total_bits <= Nativeint.size - 1 then (
      let fields = get_offsets fields in
      let int_of_foo = make_intN_of_foo _loc 0 name fields in
      let foo_of_int = make_foo_of_intN _loc 0 name fields in
      int_of_foo :: foo_of_int :: functions
    ) else functions in

  (* Write bits_of_foo and foo_of_bits functions. *)
  let functions =
    let groups = get_groups _loc name fields in
    let bits_of_foo_unsafe = make_bits_of_foo_unsafe _loc name groups in
    let bits_of_foo_string = make_bits_of_foo_string _loc name groups in
    let bits_of_foo = make_bits_of_foo _loc name groups in
    let foo_of_bits = make_foo_of_bits _loc name groups in
    let foo_of_bits_unsafe = make_foo_of_bits_unsafe _loc name groups in
    let foo_of_bits_offset = make_foo_of_bits ~offset:true _loc name groups in
    let foo_of_bits_offset_unsafe =
      make_foo_of_bits_unsafe ~offset:true _loc name groups in
    bits_of_foo_unsafe :: bits_of_foo_string :: bits_of_foo
    :: foo_of_bits_unsafe :: foo_of_bits
    :: foo_of_bits_offset_unsafe :: foo_of_bits_offset
    :: functions in

  (* Write sizebits_foo expression. *)
  let functions =
    let function_name = "bitsof_" ^ name in
    <:str_item< value $lid:function_name$ = $`int:total_bits$ >> :: functions in

  (* Write sizeof_foo expression. *)
  let functions =
    let function_name = "sizeof_" ^ name in
    let total_bytes = total_bits / 8 in
    <:str_item< value $lid:function_name$ = $`int:total_bytes$ >> :: functions in

  (* Write zero_foo expression. *)
  let functions =
    let zero_foo = make_zero_foo _loc name fields in
    zero_foo :: functions in

  (* Return the list of functions. *)
  functions

let rec str_item_concat _loc = function
  | [] -> <:str_item< >>
  | x :: xs ->
      let xs = str_item_concat _loc xs in
      <:str_item< $x$; $xs$ >>

let expand_typedefs _loc xs =
  (* Check the typedef names are all unique. *)
  let () =
    let names = List.map (fun (_, name, _, _) -> name) xs in
    check_unique _loc names in

  (* Check the types and bit sizes make sense for every field. *)
  check_fields xs;

  (* Check and parse the default options. *)
  let xs = List.map (
    fun (_loc, name, fields, default_options) ->
      _loc, name, fields, parse_options _loc default_options
  ) xs in

  (* Check and parse the field-level options *)
  let xs = List.map (
    fun (_loc, name, fields, default_options) ->
      let fields = List.map (
	fun (_loc, name, len, typ, bits, options) ->
	  let options = parse_options ~default_options _loc options in
	  _loc, name, len, typ, bits, options
      ) fields in
      _loc, name, fields, default_options
  ) xs in

  (* If bits = None, set it to the default length. *)
  let xs = List.map (
    fun (_loc, name, fields, default_options) ->
      _loc, name, set_default_bit_lengths _loc fields, default_options
  ) xs in

  (* Flatten out array fields. *)
  let xs = List.map (
    fun (_loc, name, fields, default_options) ->
      _loc, name, flatten_array_fields _loc fields, default_options
  ) xs in

  (* Make the real type definitions and functions. *)
  let typedefs = List.map make_typedef xs in
  let functions = List.concat (List.map make_functions xs) in

  (* Concatentate them into toplevel definitions. *)
  str_item_concat _loc (List.concat [typedefs; functions])

open Syntax

EXTEND Gram
  GLOBAL: str_item;

  str_item: LEVEL "top" [
    [ "type"; "struct";
      xs = LIST1 type_defn SEP "and" ->
	expand_typedefs _loc xs ]
  ];

  type_defn: [
    [ name = LIDENT; "="; "{";
      xs = LIST1 field SEP ";"; OPT ";"; "}";
      default_options = OPT [ options = STRING -> options ] ->
	(_loc, name, xs, default_options) ]
  ];

  field: [
    [ name = LIDENT;
      len = OPT [ "["; `INT (len, _); "]" -> len ];
      ":";
      typ = LIDENT;
      bits = OPT [ ":"; `INT (bits, _) -> bits ];
      options = OPT [ options = STRING -> options ] ->
	(_loc, name, len, typ, bits, options) ]
  ];

END;;
