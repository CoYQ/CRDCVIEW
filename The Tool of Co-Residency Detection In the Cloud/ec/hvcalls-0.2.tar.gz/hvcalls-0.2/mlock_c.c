/* mlock syscall for OCaml.
 * $Id: mlock_c.c,v 1.1 2007/06/14 10:00:35 rjones Exp $
 */

#include <sys/mman.h>
#include <string.h>
#include <errno.h>

#include <caml/config.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/mlvalues.h>
#include <caml/fail.h>

CAMLprim value
mlock_mlock (value datav, value lenv)
{
  CAMLparam2 (datav, lenv);
  char *data;
  int len, r;

  if (!Is_block (datav))
    caml_failwith ("mlock: first parameter must be a pointer");

  data = Bp_val (datav);
  len = Int_val (lenv);

  r = mlock (data, len);

  /* XXX Better to raise Unix_error here, but I'm lazy. */
  if (r == -1)
    caml_failwith (strerror (errno));

  CAMLreturn (Val_unit);
}

CAMLprim value
mlock_munlock (value datav, value lenv)
{
  CAMLparam2 (datav, lenv);
  char *data;
  int len, r;

  if (!Is_block (datav))
    caml_failwith ("munlock: first parameter must be a pointer");

  data = Bp_val (datav);
  len = Int_val (lenv);

  r = munlock (data, len);

  /* XXX Better to raise Unix_error here, but I'm lazy. */
  if (r == -1)
    caml_failwith (strerror (errno));

  CAMLreturn (Val_unit);
}

CAMLprim value
mlock_address_of (value obj)
{
  CAMLparam1 (obj);
  CAMLlocal1 (v);

  if (Is_block (obj)) v = caml_copy_nativeint ((intnat) obj);
  else v = caml_copy_nativeint (0);

  CAMLreturn (v);
}
