/* ioctl syscall for OCaml.
 * $Id: ioctl_c.c,v 1.2 2007/06/13 15:19:03 rjones Exp $
 */

#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>

#include <caml/config.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/mlvalues.h>
#include <caml/fail.h>

/* As with the real ioctl(2), it is the callers responsibility to
 * make sure that the data parameter is a large enough string to
 * store the whole value passed in or out of the ioctl.  We don't
 * (more accurately, can't) perform any checks.
 */
CAMLprim value
caml_ioctl (value fdv, value cmdv, value datav)
{
  CAMLparam3 (fdv, cmdv, datav);
  CAMLlocal1 (rv);
  int fd, cmd, r;
  char *data;

  fd = Int_val (fdv);
  cmd = Int32_val (cmdv);
  data = String_val (datav);

  r = ioctl (fd, cmd, (unsigned long) data);

  /* XXX Better to raise Unix_error here, but I'm lazy. */
  if (r == -1)
    caml_failwith (strerror (errno));

  rv = caml_copy_int32 (r);

  CAMLreturn (rv);
}
