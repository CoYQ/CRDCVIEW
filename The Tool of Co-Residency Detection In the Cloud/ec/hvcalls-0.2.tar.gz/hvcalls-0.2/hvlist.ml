(* Try listing all domains.
 * $Id: hvlist.ml,v 1.8 2007/06/14 17:49:58 rjones Exp $
 *)

open Printf

open Ioctl
open Mlock

(* Hypercall block. *)
type struct hypercall = {
  op : int64;
  arg[5] : int64
}

(* System operation. hypercall.arg0 points to this. *)
type struct system_operation = {
  cmd : int32;
  interface_version : int32;
  first_domain : int32;
  max_domains : int32;
  domain_info : int64;			(* data is returned here *)
  num_domains : int32;
  padding[128] : char
}

(* Hypercall cmd number (second arg of ioctl). *)
let ioctl_privcmd_hypercall =
  Linux.int32_of_ioc {
    Linux.dir = Linux.ioc_none;
    typ = 80; (* 'P' *)
    nr = 0;
    size = sizeof_hypercall;
  }

(* Hypercall codes. *)
let hypervisor_xen_version = 17_L
let xenver_version = 0_L
let xen_v2_op_getdomaininfolist = 6_l
let sys_interface_version = 3_l
let hypervisor_sysctl = 35_L

(* xenver_version returns packed major shl 16 | minor. *)
type struct xen_packed_version = {
  major : int:16;
  minor : int:16
}

(* getdomaininfo structure (v2d5). *)
type struct xen_getdomaininfo = {
  domain : int32;			(* only bottom 16 bits are used *)
  flags : int32;
  tot_pages : int64;
  max_pages : int64;
  shared_info_frame : int64;
  cpu_time : int64;
  nr_online_vcpus : int32;
  max_vcpu_id : int32;
  ssidref : int32;
  padding : int32;			(* XXX probably only on 64 bit *)
  handle[16] : char
}

let fd = Unix.openfile "/proc/xen/privcmd" [Unix.O_RDWR] 0

let detect_hv_version () =
  (* Make new-style hypercall. *)
  let hc = bits_of_hypercall {
    zero_hypercall with
      op = hypervisor_xen_version;
      arg0 = xenver_version
  } in
  let r = ioctl fd ioctl_privcmd_hypercall hc in

  (* Unpack major:minor. *)
  let { major = major; minor = minor } = xen_packed_version_of_int32 r in
  major, minor

let get_domain_info_list first maxids =
  let domain_list, operation =
    with_no_compaction (
      fun () ->
	(* Allocate enough memory for the returned list. *)
	let domain_list = String.create (maxids * sizeof_xen_getdomaininfo) in

	(* Allocate the sys operation. *)
	let operation = bits_of_system_operation {
	  zero_system_operation with
	    cmd = xen_v2_op_getdomaininfolist;
	    interface_version = sys_interface_version;
	    first_domain = Int32.of_int first;
	    max_domains = Int32.of_int maxids;
	    domain_info = Int64.of_nativeint (address_of domain_list);
	    num_domains = Int32.of_int maxids
	} in

	with_mlock [domain_list; operation] (
	  fun () ->
	    let hc = bits_of_hypercall {
	      zero_hypercall with
		op = hypervisor_sysctl;
		arg0 = Int64.of_nativeint (address_of operation)
	    } in
	    ignore (ioctl fd ioctl_privcmd_hypercall hc)
	);

	domain_list, operation
    ) in

  (* The result (domain info structures) are packed into the bitstring
   * called domain_list.  However Xen also returns the number of domains,
   * in the operation field, so unpack that first.
   *)
  let {num_domains = num_domains} = system_operation_of_bits operation in
  let num_domains = Int32.to_int num_domains in

  let array = Array.init num_domains (
    fun i ->
      xen_getdomaininfo_of_bits'offset
	domain_list (i * sizeof_xen_getdomaininfo)
  ) in

  Array.to_list array

let () =
  let major, minor = detect_hv_version () in
  printf "hypervisor version = %d : %d\n" major minor;
  let domains = get_domain_info_list 0 100 in
  printf "number of domains = %d\n" (List.length domains);
  List.iter (
    fun domain ->
      printf "dom %ld\n" domain.domain;
      printf "  flags 0x%lx\n" domain.flags;
      printf "  tot_pages %Ld\n" domain.tot_pages;
      printf "  max_pages %Ld\n" domain.max_pages;
      printf "  shared_info_frame %Ld\n" domain.shared_info_frame;
      printf "  cpu_time %Ld\n" domain.cpu_time;
      printf "  nr_online_vcpus %ld\n" domain.nr_online_vcpus;
      printf "  max_vcpu_id %ld\n" domain.max_vcpu_id;
      printf "  ssidref %ld\n" domain.ssidref;
      printf "  handle[0] %d\n" (Char.code domain.handle0);
      printf "  handle[15] %d\n" (Char.code domain.handle15);
  ) domains
