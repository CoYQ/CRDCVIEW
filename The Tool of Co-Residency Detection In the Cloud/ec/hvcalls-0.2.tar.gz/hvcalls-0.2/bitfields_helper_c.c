/* Helper functions for pa_bitfields macro.
 * $Id: bitfields_helper_c.c,v 1.2 2007/06/14 16:51:07 rjones Exp $
 */

#include <endian.h>
#include <byteswap.h>

#include <caml/config.h>
#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/mlvalues.h>
#include <caml/fail.h>

CAMLprim value
bitfields_helper_platform_endianness (value unitv)
{
  CAMLparam1 (unitv);
  CAMLlocal1 (rv);

#if __BYTE_ORDER == __BIG_ENDIAN
  rv = Val_int (0);
#elif __BYTE_ORDER == __LITTLE_ENDIAN
  rv = Val_int (1);
#else
#error "unknown endianness"
#endif
  CAMLreturn (rv);
}

/* It ought to be possible to do these as "noalloc" functions, so there
 * is no GC or function entry overhead. (XXX)
 */

void bitfields_helper_write_int_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_int_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_int_64_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_int_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }

CAMLprim value
bitfields_helper_write_int32_32_le_unsafe (value iv, value strv, value offv)
{
  CAMLparam3 (iv, strv, offv);
  int32_t i = Int32_val (iv);
  char *str = String_val (strv);
  int off = Int_val (offv);

  str += off;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  *(int32_t*)str = i;
#else
  *(int32_t*)str = bswap_32 (i);
#endif

  CAMLreturn (Val_unit);
}

void bitfields_helper_write_int32_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_int64_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_int64_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }

CAMLprim value
bitfields_helper_write_int64_64_le_unsafe (value iv, value strv, value offv)
{
  CAMLparam3 (iv, strv, offv);
  int64_t i = Int64_val (iv);
  char *str = String_val (strv);
  int off = Int_val (offv);

  str += off;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  *(int64_t*)str = i;
#else
  *(int64_t*)str = bswap_64 (i);
#endif

  CAMLreturn (Val_unit);
}

void bitfields_helper_write_int64_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_nativeint_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_nativeint_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_nativeint_64_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_write_nativeint_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }

void bitfields_helper_read_int_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_int_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_int_64_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_int_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }

CAMLprim value
bitfields_helper_read_int32_32_le_unsafe (value strv, value offv)
{
  CAMLparam2 (strv, offv);
  CAMLlocal1 (iv);
  char *str = String_val (strv);
  int off = Int_val (offv);
  int32_t i;

  str += off;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  i = *(int32_t*)str;
#else
  i = bswap_32 (*(int32_t*)str);
#endif

  iv = caml_copy_int32 (i);

  CAMLreturn (iv);
}

void bitfields_helper_read_int32_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_int64_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_int64_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }

CAMLprim value
bitfields_helper_read_int64_64_le_unsafe (value strv, value offv)
{
  CAMLparam2 (strv, offv);
  CAMLlocal1 (iv);
  char *str = String_val (strv);
  int off = Int_val (offv);
  int64_t i;

  str += off;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  i = *(int64_t*)str;
#else
  i = bswap_64 (*(int64_t*)str);
#endif

  iv = caml_copy_int64 (i);

  CAMLreturn (iv);
}

void bitfields_helper_read_int64_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_nativeint_32_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_nativeint_32_be_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_nativeint_64_le_unsafe (void) { caml_failwith (__FUNCTION__); }
void bitfields_helper_read_nativeint_64_be_unsafe (void) { caml_failwith (__FUNCTION__); }
