(* mlock syscall for OCaml.
 * $Id: mlock.ml,v 1.3 2007/06/14 16:51:07 rjones Exp $
 *)

external mlock : 'a -> int -> unit = "mlock_mlock"
external munlock : 'a -> int -> unit = "mlock_munlock"

let mlock_string str =
  mlock str (String.length str)

let munlock_string str =
  munlock str (String.length str)

type 'a result = Result of 'a | Exn of exn

let with_mlock strings f =
  (* Run a minor collection so that all objects are in the major heap. *)
  Gc.minor ();
  (* Lock the strings. *)
  List.iter mlock_string strings;
  (* Call f () *)
  let result = try Result (f ()) with exn -> Exn exn in
  (* Unlock the strings. *)
  List.iter munlock_string strings;
  (* Return or re-raise any exception. *)
  match result with Result a -> a | Exn exn -> raise exn

let with_no_compaction f =
  (* Disable compaction. *)
  let ctrl = Gc.get () in
  let old_max_overhead = ctrl.Gc.max_overhead in
  Gc.set { ctrl with Gc.max_overhead = 1000000 };
  (* Call f () *)
  let result = try Result (f ()) with exn -> Exn exn in
  (* Restore compaction. *)
  let ctrl = Gc.get () in
  let ctrl = { ctrl with Gc.max_overhead = old_max_overhead } in
  Gc.set ctrl;
  (* Return or re-raise any exception. *)
  match result with Result a -> a | Exn exn -> raise exn

external address_of : 'a -> nativeint = "mlock_address_of"
