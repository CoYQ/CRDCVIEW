(* Helper functions for pa_bitfields macro.
 * $Id: bitfields_helper.ml,v 1.2 2007/06/14 16:51:07 rjones Exp $
 *)

type endianness = Big_Endian | Little_Endian

let string_of_endianness = function
  | Big_Endian -> "Big_Endian"
  | Little_Endian -> "Little_Endian"

(* Endianness of the current platform. *)
external platform_endianness : unit -> endianness = "bitfields_helper_platform_endianness"

external write_int_32_le_unsafe : int -> string -> int -> unit = "bitfields_helper_write_int_32_le_unsafe"
external write_int_32_be_unsafe : int -> string -> int -> unit = "bitfields_helper_write_int_32_be_unsafe"
external write_int_64_le_unsafe : int -> string -> int -> unit = "bitfields_helper_write_int_64_le_unsafe"
external write_int_64_be_unsafe : int -> string -> int -> unit = "bitfields_helper_write_int_64_be_unsafe"
external write_int32_32_le_unsafe : int32 -> string -> int -> unit = "bitfields_helper_write_int32_32_le_unsafe"
external write_int32_32_be_unsafe : int32 -> string -> int -> unit = "bitfields_helper_write_int32_32_be_unsafe"
external write_int64_32_le_unsafe : int64 -> string -> int -> unit = "bitfields_helper_write_int64_32_le_unsafe"
external write_int64_32_be_unsafe : int64 -> string -> int -> unit = "bitfields_helper_write_int64_32_be_unsafe"
external write_int64_64_le_unsafe : int64 -> string -> int -> unit = "bitfields_helper_write_int64_64_le_unsafe"
external write_int64_64_be_unsafe : int64 -> string -> int -> unit = "bitfields_helper_write_int64_64_be_unsafe"
external write_nativeint_32_le_unsafe : nativeint -> string -> int -> unit = "bitfields_helper_write_nativeint_32_le_unsafe"
external write_nativeint_32_be_unsafe : nativeint -> string -> int -> unit = "bitfields_helper_write_nativeint_32_be_unsafe"
external write_nativeint_64_le_unsafe : nativeint -> string -> int -> unit = "bitfields_helper_write_nativeint_64_le_unsafe"
external write_nativeint_64_be_unsafe : nativeint -> string -> int -> unit = "bitfields_helper_write_nativeint_64_be_unsafe"

external read_int_32_le_unsafe : string -> int -> int = "bitfields_helper_read_int_32_le_unsafe"
external read_int_32_be_unsafe : string -> int -> int = "bitfields_helper_read_int_32_be_unsafe"
external read_int_64_le_unsafe : string -> int -> int = "bitfields_helper_read_int_64_le_unsafe"
external read_int_64_be_unsafe : string -> int -> int = "bitfields_helper_read_int_64_be_unsafe"
external read_int32_32_le_unsafe : string -> int -> int32 = "bitfields_helper_read_int32_32_le_unsafe"
external read_int32_32_be_unsafe : string -> int -> int32 = "bitfields_helper_read_int32_32_be_unsafe"
external read_int64_32_le_unsafe : string -> int -> int64 = "bitfields_helper_read_int64_32_le_unsafe"
external read_int64_32_be_unsafe : string -> int -> int64 = "bitfields_helper_read_int64_32_be_unsafe"
external read_int64_64_le_unsafe : string -> int -> int64 = "bitfields_helper_read_int64_64_le_unsafe"
external read_int64_64_be_unsafe : string -> int -> int64 = "bitfields_helper_read_int64_64_be_unsafe"
external read_nativeint_32_le_unsafe : string -> int -> nativeint = "bitfields_helper_read_nativeint_32_le_unsafe"
external read_nativeint_32_be_unsafe : string -> int -> nativeint = "bitfields_helper_read_nativeint_32_be_unsafe"
external read_nativeint_64_le_unsafe : string -> int -> nativeint = "bitfields_helper_read_nativeint_64_le_unsafe"
external read_nativeint_64_be_unsafe : string -> int -> nativeint = "bitfields_helper_read_nativeint_64_be_unsafe"
